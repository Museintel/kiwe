# Start authoring kit 9.7

Attach this complete ZIP alongside your safe project brief and Kiwe Design Context/SiteGraph. Paste PROMPT.txt into a new AI chat: the canonical Start URL and /ideate. After reviewing the usage brief, send /preview; after reviewing that preview, send /seam. Do not stack those commands in one first message.

Canonical: https://start.kiwelaunch.com/start.md
Pinned: https://start.kiwelaunch.com/v/9.7-6f6ff8c091a5/start.md

If online Start cannot be read, verify every file against handoff.json, then read start.md, command-manifest.json, contracts/authoring-delivery.md and the matching contexts/ file locally. Read relevant reference/index.json entries only as needed. The complete public library is available without copying its long pointer table into the prompt. No customer/site data, credentials, prior generated design or live MCP connection is included.

With an existing Node 20+ runtime, run node start/bin/kiwe.js inspect-bindings PATH_TO_SITEGRAPH and node start/bin/kiwe.js validate-seam-map PROJECT. New outputs also run node start/bin/kiwe.js validate-preview PROJECT. No package install, browser install or configuration workaround is needed.

Keep this start/ folder in transferable output ZIPs with the formal discovery, bootstrap receipt, semantic map, real local assets and preview receipt. Browser testing remains a separate real action; these tools never claim to execute it.
